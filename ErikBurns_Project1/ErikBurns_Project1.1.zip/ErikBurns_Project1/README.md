GVR_SDK_VERSION = "1.0";

= What I Liked =
I liked the simplicity of this project, and a quick start with some VR candy!
The project was a good example of the publishing workflow and also how to submit
a project for review by Udacity.

= What I found Challenging =
Navigating the scene view within Unity without a mouse (using Macbook trackpad)
is a bit challenging. Moving forward, I may use my external mouse while in Unity.
Also, it was hard to find which version of the Google VR SDK I was using. I had
to Google for a bit to figure it out, and finally asked my Udacity mentor.
